# Cloud IP addresses

/// warning | Cloud IP addresses change without warning
n8n can't guarantee static source IPs, as Cloud operates in a dynamic cloud provider environment and scales its infrastructure to meet demand. You should use strong authentication and secure transport protocols when connecting into and out of n8n.
///

Outbound traffic may appear to originate from any of:

* 20.79.227.226/32
* 20.113.47.122/32
* 20.218.202.73/32
* 98.67.233.91/32
* 4.182.111.50/32
* 4.182.129.20/32
* 4.182.88.118/32
* 4.182.212.136/32
* 98.67.244.108/32
* 72.144.128.145/32
* 72.144.83.147/32
* 72.144.69.38/32
* 72.144.111.50/32
* 4.182.128.108/32
* 4.182.190.144/32
* 4.182.191.184/32
* 98.67.233.200/32

* 20.52.126.0/28
* 20.218.238.112/28
* 4.182.64.64/28
* 20.218.174.0/28
* 4.184.78.240/28
* 20.79.32.32/28
* 51.116.119.64/28
* 51.107.180.112/28
* 4.165.103.112/28
* 9.223.34.48/28
* 20.240.204.176/28
* 20.240.52.208/28
